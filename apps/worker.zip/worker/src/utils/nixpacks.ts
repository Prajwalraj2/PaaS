// ═══════════════════════════════════════════════════════════════════════════
// Nixpacks Utilities
// ═══════════════════════════════════════════════════════════════════════════
//
// Nixpacks automatically detects application type and builds Docker images
// without requiring a Dockerfile. Similar to Heroku/Railway buildpacks.
//
// Supports: Node.js, Python, Go, Rust, Ruby, PHP, Java, and more.
//
// We use the Docker-based approach (no local Nixpacks CLI install required):
//   docker run -v <source>:/app ghcr.io/railwayapp/nixpacks build /app --name <tag>
//
// ═══════════════════════════════════════════════════════════════════════════

import { spawn, exec } from 'child_process';
import type { BuildContext } from '../types';
import { addLog } from './log-helper';
import { logger } from '../lib/logger';

// ─────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────

export interface NixpacksBuildOptions {
  context: BuildContext;
  workDir: string;
  imageTag: string;
  envVars?: Record<string, string>;
  startCommand?: string;
  buildCommand?: string;
}

export interface NixpacksBuildResult {
  success: boolean;
  imageTag: string;
  imageSizeBytes?: number;
  error?: string;
}

// Nixpacks Docker image (Railway's official image)
const NIXPACKS_IMAGE = 'ghcr.io/railwayapp/nixpacks:latest';

// Check if running on Windows
const IS_WINDOWS = process.platform === 'win32';

// ─────────────────────────────────────────────────────────────────
// PATH HELPERS (Windows compatibility)
// ─────────────────────────────────────────────────────────────────

/**
 * Convert Windows path to Docker-compatible POSIX path.
 * Example: C:\tmp\paas-builds\app -> /c/tmp/paas-builds/app
 */
function toDockerPath(windowsPath: string): string {
  if (!IS_WINDOWS) return windowsPath;
  
  // Replace backslashes with forward slashes
  let dockerPath = windowsPath.replace(/\\/g, '/');
  
  // Convert drive letter: C:/... -> /c/...
  const driveMatch = dockerPath.match(/^([A-Za-z]):\//);
  if (driveMatch) {
    const driveLetter = driveMatch[1].toLowerCase();
    dockerPath = `/${driveLetter}${dockerPath.slice(2)}`;
  }
  
  return dockerPath;
}

// ─────────────────────────────────────────────────────────────────
// NIXPACKS BUILD
// ─────────────────────────────────────────────────────────────────

/**
 * Build a Docker image using Nixpacks (auto-detect language/framework).
 * Uses the Nixpacks Docker image, so no local CLI installation is required.
 *
 * Streams build output to the context logs in real-time.
 */
export async function nixpacksBuild(options: NixpacksBuildOptions): Promise<NixpacksBuildResult> {
  const { context, workDir, imageTag, envVars, startCommand, buildCommand } = options;

  addLog(context, 'info', 'Building with Nixpacks (auto-detect)...', 'build');
  addLog(context, 'info', `Source: ${workDir}`, 'build');
  addLog(context, 'info', `Target image: ${imageTag}`, 'build');

  // Convert Windows path to Docker-compatible format
  const dockerWorkDir = toDockerPath(workDir);
  addLog(context, 'info', `Docker mount path: ${dockerWorkDir}`, 'build');

  // Build the docker command as a single string for Windows compatibility
  // On Windows, shell parsing with array args can break the command
  const cmdParts: string[] = [
    'docker run --rm',
    // Mount the source directory (use Docker-compatible path)
    `-v "${dockerWorkDir}:/app"`,
    // Mount Docker socket so nixpacks can build images on host Docker
    // On Windows with Docker Desktop, //var/run/docker.sock maps correctly
    `-v ${IS_WINDOWS ? '//var/run/docker.sock:/var/run/docker.sock' : '/var/run/docker.sock:/var/run/docker.sock'}`,
    // Nixpacks image
    NIXPACKS_IMAGE,
    // Nixpacks command: build /app --name <tag>
    'build /app',
    `--name "${imageTag}"`,
  ];

  // Add environment variables for build/runtime
  if (envVars && Object.keys(envVars).length > 0) {
    for (const [key, value] of Object.entries(envVars)) {
      // --env KEY=VALUE sets runtime env vars in the built image
      cmdParts.push(`--env "${key}=${value}"`);
    }
  }

  // Custom start command (overrides auto-detected)
  if (startCommand) {
    cmdParts.push(`--start-cmd "${startCommand}"`);
  }

  // Custom build command (overrides auto-detected)
  if (buildCommand) {
    cmdParts.push(`--build-cmd "${buildCommand}"`);
  }

  const fullCommand = cmdParts.join(' ');
  
  logger.info({ 
    imageTag, 
    workDir, 
    dockerWorkDir,
    envCount: Object.keys(envVars || {}).length,
    command: fullCommand,
  }, 'Starting Nixpacks build');
  
  addLog(context, 'debug', `Command: ${fullCommand}`, 'build');

  return new Promise((resolve) => {
    // Use exec with a single command string for better Windows compatibility
    const docker = exec(fullCommand, {
      maxBuffer: 50 * 1024 * 1024, // 50MB buffer for build output
    });

    let hasError = false;
    let errorMessage = '';

    docker.stdout?.on('data', (data: string | Buffer) => {
      const lines = data.toString().split('\n').filter((line) => line.trim());
      for (const line of lines) {
        addLog(context, 'info', line, 'build');
      }
    });

    docker.stderr?.on('data', (data: string | Buffer) => {
      const lines = data.toString().split('\n').filter((line) => line.trim());
      for (const line of lines) {
        // Nixpacks outputs progress to stderr (not always errors)
        // Check for actual error indicators
        const lowerLine = line.toLowerCase();
        if ((lowerLine.includes('error') && !lowerLine.includes('error:')) ||
            lowerLine.includes('failed') ||
            lowerLine.includes('denied') ||
            lowerLine.startsWith('error:')) {
          addLog(context, 'error', line, 'build');
          hasError = true;
          errorMessage += line + '\n';
        } else {
          // Progress output (Nixpacks logs to stderr)
          addLog(context, 'info', line, 'build');
        }
      }
    });

    docker.on('error', (err) => {
      logger.error({ err }, 'Nixpacks process error');
      addLog(context, 'error', `Nixpacks process error: ${err.message}`, 'build');
      hasError = true;
      errorMessage = err.message;
    });

    docker.on('close', async (code) => {
      if (code === 0 && !hasError) {
        addLog(context, 'info', 'Nixpacks build completed successfully ✅', 'build');

        // Get image size
        const sizeBytes = await getImageSize(imageTag);
        if (sizeBytes) {
          addLog(context, 'info', `Image size: ${formatBytes(sizeBytes)}`, 'build');
        }

        resolve({
          success: true,
          imageTag,
          imageSizeBytes: sizeBytes,
        });
      } else {
        const msg = errorMessage || `Nixpacks build failed with exit code ${code}`;
        addLog(context, 'error', `Build failed: ${msg}`, 'build');
        logger.error({ code, errorMessage }, 'Nixpacks build failed');

        resolve({
          success: false,
          imageTag,
          error: msg,
        });
      }
    });
  });
}

// ─────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────

/**
 * Get the size of a Docker image in bytes.
 */
async function getImageSize(imageTag: string): Promise<number | undefined> {
  return new Promise((resolve) => {
    const docker = spawn('docker', ['image', 'inspect', imageTag, '--format', '{{.Size}}'], {
      shell: true,
    });

    let output = '';

    docker.stdout.on('data', (data: Buffer) => {
      output += data.toString();
    });

    docker.on('close', (code) => {
      if (code === 0) {
        const size = parseInt(output.trim(), 10);
        resolve(isNaN(size) ? undefined : size);
      } else {
        resolve(undefined);
      }
    });

    docker.on('error', () => {
      resolve(undefined);
    });
  });
}

/**
 * Format bytes to human-readable string.
 */
function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Check if Nixpacks Docker image is available locally.
 * If not, it will be pulled on first use.
 */
export async function checkNixpacksAvailable(): Promise<boolean> {
  return new Promise((resolve) => {
    const docker = spawn('docker', ['image', 'inspect', NIXPACKS_IMAGE], { shell: true });

    docker.on('close', (code) => {
      resolve(code === 0);
    });

    docker.on('error', () => {
      resolve(false);
    });
  });
}

/**
 * Pull the Nixpacks Docker image (one-time setup).
 */
export async function pullNixpacksImage(): Promise<boolean> {
  return new Promise((resolve) => {
    const docker = spawn('docker', ['pull', NIXPACKS_IMAGE], { shell: true });

    docker.on('close', (code) => {
      resolve(code === 0);
    });

    docker.on('error', () => {
      resolve(false);
    });
  });
}
